package com.thoughtworks.rnr.interceptor;

import com.thoughtworks.rnr.service.SAMLService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mock;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.*;

import static org.mockito.MockitoAnnotations.initMocks;

public class HomeInterceptorTest {

    private final String REDIRECT_URL = "https://thoughtworks.oktapreview.com/app/template_saml_2_0/k21tpw64VPAMDOMKRXBS/sso/samlSpike";
    @Mock
    SAMLService mockSAMLService;
    @Mock
    HttpServletRequest mockHttpServletRequest;
    @Mock
    HttpServletResponse mockHttpServletResponse;
    @Mock
    Object handler;
    private HomeInterceptor homeInterceptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        homeInterceptor = new HomeInterceptor(mockSAMLService);
    }

    @Test
    public void interceptRedirectsToOKTA() throws Exception {
        boolean interceptorResult = homeInterceptor.preHandle(mockHttpServletRequest, mockHttpServletResponse, handler);
        verify(mockHttpServletResponse).sendRedirect(REDIRECT_URL);
        assertFalse(interceptorResult);
    }
}
