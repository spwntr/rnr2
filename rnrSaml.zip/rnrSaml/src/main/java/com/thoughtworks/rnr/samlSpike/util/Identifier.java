package com.thoughtworks.rnr.samlSpike.util;

/**
 * An interface for an identifier used for creating a SAMLRequest
 */
public interface Identifier {

    public String getId();

}
