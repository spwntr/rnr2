package com.thoughtworks.rnr.samlSpike;

import org.opensaml.DefaultBootstrap;
import org.opensaml.ws.security.SecurityPolicyException;
import org.opensaml.xml.ConfigurationException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Wrapper for the other Okta SAML classes
 * Runs the initialization for libraries used by the other classes
 */
public class SAMLValidator {

    private static final Logger logger = Logger.getLogger(SAMLValidator.class.getName());

    public SAMLValidator() throws SecurityPolicyException {
        try {
            DefaultBootstrap.bootstrap();
        } catch (ConfigurationException e) {
            logger.log(Level.WARNING, e.getMessage());
            throw new SecurityPolicyException("Problem while bootstrapping openSAML library");
        }
    }

    public Configuration getConfiguration(String config) throws SecurityPolicyException {
        try {
            return new Configuration(config);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Failed to create new Configuration instance", e);
            throw new SecurityPolicyException("Problem parsing the configuration.");
        }
    }

    public Configuration getConfigurationFrom(String path) throws SecurityPolicyException, IOException {
        FileInputStream stream = null;
        try {
            stream= new FileInputStream(new File(path));
            FileChannel channel = stream.getChannel();
            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
            String config = Charset.forName("UTF-8").decode(buffer).toString();
            return getConfiguration(config);
        } catch (FileNotFoundException e) {
            logger.log(Level.WARNING, "File not found. Current path: " + new File(".").getAbsolutePath());
            throw e;
        } finally {
            if (stream != null) stream.close();
        }
    }

    public SAMLRequest getSAMLRequest(Application application) {
        return new SAMLRequest(application);
    }

    public SAMLResponse getSAMLResponse(String responseString, Configuration configuration) throws SecurityPolicyException {
        return new SAMLResponse(responseString, configuration);
    }
}
