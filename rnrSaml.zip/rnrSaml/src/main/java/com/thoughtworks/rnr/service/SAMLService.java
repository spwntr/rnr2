package com.thoughtworks.rnr.service;

import com.thoughtworks.rnr.samlSpike.Application;
import com.thoughtworks.rnr.samlSpike.Configuration;
import com.thoughtworks.rnr.samlSpike.SAMLRequest;
import com.thoughtworks.rnr.samlSpike.SAMLValidator;
import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class SAMLService {

    protected static final String SAML_REQUEST = "SAMLRequest";

    private static final Logger logger = Logger.getLogger(SAMLService.class.getName());

    protected Application app;

    public SAMLValidator validator;
    public Configuration configuration;

    public SAMLService() {
        try {
            InputStream stream = getClass().getResourceAsStream("/saml-config.xml");
            String fileAsString;
            try {
                fileAsString = convertStreamToString(stream);
            } finally {
                stream.close();
            }

            validator = new SAMLValidator();

            configuration = validator.getConfiguration(fileAsString);
            app = configuration.getDefaultApplication();

            if (configuration.getDefaultEntityID() == null) {
                logger.log(Level.WARNING, "Default application has not been configured in configuration.");
            } else if (app == null) {
                logger.log(Level.WARNING, "Could not find default application in configuration: " + configuration.getDefaultEntityID());
            }
        } catch (Exception e) {
            logger.log(Level.WARNING, "error");
            e.printStackTrace();
        }
    }

    public void oktaRedirect(HttpServletResponse response) {
        try {
            SAMLRequest samlRequest = validator.getSAMLRequest(app);
            String encodedSaml = Base64.encodeBase64String(samlRequest.toString().getBytes());
            String url = app.getAuthenticationURL();
            // appAuthURL + "SAML-Request" + SAMLRequest
            url += "?" + SAML_REQUEST + "=" + URLEncoder.encode(encodedSaml, "UTF-8");
            logger.info("Redirecting to: " + url);
            response.sendRedirect(url);
        } catch (Exception e) {
            logger.log(Level.WARNING, e.getMessage());
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    private static String convertStreamToString(java.io.InputStream is) {
        java.util.Scanner s = new java.util.Scanner(is, "UTF-8").useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }
}

