package com.thoughtworks.rnr.samlSpike;

import com.sun.org.apache.xpath.internal.jaxp.XPathFactoryImpl;
import org.apache.commons.lang3.StringUtils;
import org.opensaml.ws.security.SecurityPolicyException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.xpath.*;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class is derived from a xml configuration file;
 * it is used to provide an application required to generate a SAMLRequest,
 * and to oktaRedirect SAMLResponse.
 */
public class Configuration {

    private Map<String, Application> applications;
    private String defaultEntityID = null;
    private boolean suppressErrors;
    private String loginUri;

    static XPath XPATH;

    private static XPathExpression CONFIGURATION_ROOT_XPATH;
    private static XPathExpression APPLICATIONS_XPATH;
    private static XPathExpression ENTITY_ID_XPATH;
    private static XPathExpression DEFAULT_APP_XPATH;
    private static XPathExpression ADDRESSES_XPATH;
    private static XPathExpression SP_USERNAMES_XPATH;
    private static XPathExpression SP_GROUPS_XPATH;
    private static XPathExpression SUPPRESS_ERRORS_XPATH;
    private static XPathExpression LOGIN_URI_XPATH;

    private List<String> spUsernames;
    private List<String> spGroupnames;

    public static final String SAML_RESPONSE_FORM_NAME = "SAMLResponse";
    public static final String CONFIGURATION_KEY = "okta.config.file";
    public static final String DEFAULT_ENTITY_ID = "okta.config.default_entity_id";
    public static final String REDIR_PARAM = "os_destination";
    public static final String RELAY_STATE_PARAM = "RelayState";

    private static final Logger logger = Logger.getLogger(Configuration.class.getName());

    static {
        try {
            XPathFactory xPathFactory = new XPathFactoryImpl();
            XPATH = xPathFactory.newXPath();
            XPATH.setNamespaceContext(new MetadataNamespaceContext());

            CONFIGURATION_ROOT_XPATH = XPATH.compile("configuration");
            APPLICATIONS_XPATH = XPATH.compile("applications/application");
            ADDRESSES_XPATH = XPATH.compile("allowedAddresses");
            SP_USERNAMES_XPATH = XPATH.compile("spUsers/username");
            SP_GROUPS_XPATH = XPATH.compile("spGroups/groupname");
            ENTITY_ID_XPATH = XPATH.compile("md:EntityDescriptor/@entityID");
            DEFAULT_APP_XPATH = XPATH.compile("default");
            SUPPRESS_ERRORS_XPATH = XPATH.compile("suppressErrors");
            LOGIN_URI_XPATH = XPATH.compile("loginUri");
        } catch (XPathExpressionException e) {
            logger.log(Level.WARNING, "Failed to create XPathFactory instance", e);
        }
    }

    public Configuration(String configuration) throws XPathExpressionException, CertificateException, UnsupportedEncodingException, SecurityPolicyException {
        InputSource source = new InputSource(new StringReader(configuration));

        Node root = (Node) CONFIGURATION_ROOT_XPATH.evaluate(source, XPathConstants.NODE);
        NodeList applicationNodes = (NodeList) APPLICATIONS_XPATH.evaluate(root, XPathConstants.NODESET);

        defaultEntityID = DEFAULT_APP_XPATH.evaluate(root);
        applications = new HashMap<String, Application>();
        spUsernames = new ArrayList<String>();
        spGroupnames = new ArrayList<String>();

        for (int i = 0; i < applicationNodes.getLength(); i++) {
            Element applicationNode = (Element) applicationNodes.item(i);
            String entityID = ENTITY_ID_XPATH.evaluate(applicationNode);
            Application application = new Application(applicationNode);
            applications.put(entityID, application);
        }

        String suppress = SUPPRESS_ERRORS_XPATH.evaluate(root);
        if (suppress != null) {
            suppress = suppress.trim();
        }
        suppressErrors = (!StringUtils.isBlank(suppress)) ? Boolean.parseBoolean(suppress) : true;

        loginUri = LOGIN_URI_XPATH.evaluate(root);
        if (loginUri != null) {
            loginUri = loginUri.trim();
        }

        NodeList spUnames = (NodeList) SP_USERNAMES_XPATH.evaluate(root, XPathConstants.NODESET);
        if (spUnames != null) {
            for (int i = 0; i < spUnames.getLength(); i++) {
                Element usernameNode = (Element) spUnames.item(i);
                if (!StringUtils.isBlank(usernameNode.getTextContent())) {
                    spUsernames.add(usernameNode.getTextContent().trim());
                }
            }
        }

        NodeList spGnames = (NodeList) SP_GROUPS_XPATH.evaluate(root, XPathConstants.NODESET);
        if (spGnames != null) {
            for (int i = 0; i < spGnames.getLength(); i++) {
                Element groupnameNode = (Element) spGnames.item(i);
                if (!StringUtils.isBlank(groupnameNode.getTextContent())) {
                    spGroupnames.add(groupnameNode.getTextContent().trim());
                }
            }
        }
    }

    public Map<String, Application> getApplications() {
        return applications;
    }

    public Application getApplication(String entityID) {
        return applications.get(entityID);
    }

    public Application getDefaultApplication() {
        if (StringUtils.isBlank(defaultEntityID)) {
            return null;
        }
        return applications.get(defaultEntityID);
    }

    public String getDefaultEntityID() {
        return defaultEntityID;
    }

    public boolean isUsernameAllowedForOkta(String username) {
        if (StringUtils.isBlank(username)) {
            return true;
        }
        return !spUsernames.contains(username);
    }

    public boolean isInSPGroups(Collection<String> userGroups) {
        if (userGroups == null || userGroups.isEmpty() || spGroupnames.isEmpty()) {
            return false;
        }

        for (String atlGroup: spGroupnames) {
            for (String userGroup : userGroups) {
                if (userGroup.trim().equalsIgnoreCase(atlGroup.trim())) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isSPUsernamesUsed() {
        return !spUsernames.isEmpty();
    }

    public boolean isSPGroupnamesUsed() {
        return !spGroupnames.isEmpty();
    }

    public boolean suppressingErrors() {
        return suppressErrors;
    }

    public String getLoginUri() {
        return loginUri;
    }
}