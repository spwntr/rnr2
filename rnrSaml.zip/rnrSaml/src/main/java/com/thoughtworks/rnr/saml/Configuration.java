package com.thoughtworks.rnr.saml;

import org.springframework.stereotype.Component;

@Component
public class Configuration {
}
