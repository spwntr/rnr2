package com.thoughtworks.rnr.interceptor;

import com.thoughtworks.rnr.samlSpike.SAMLResponse;
import com.thoughtworks.rnr.samlSpike.util.OktaAuthPeer;
import com.thoughtworks.rnr.service.SAMLService;
import org.apache.commons.codec.binary.Base64;
import org.opensaml.ws.security.SecurityPolicyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.Charset;
import java.security.Principal;

public class OktaInterceptor extends HandlerInterceptorAdapter {

    private SAMLService SAMLService;
    protected static final String SAML_RESPONSE = "SAMLResponse";

    @Autowired
    public OktaInterceptor(SAMLService SAMLService) {
        this.SAMLService = SAMLService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        try {
            String assertion = request.getParameter(SAML_RESPONSE);
            if (assertion == null) {
                throw new Exception("SAMLResponse parameter missing");
            }
            assertion = new String(Base64.decodeBase64(assertion.getBytes("UTF-8")), Charset.forName("UTF-8"));
            System.out.println(assertion);

            SAMLResponse samlResponse = SAMLService.validator.getSAMLResponse(assertion, SAMLService.configuration);
            System.out.println("SAML authentication successful");

//            HttpSession session = request.getSession(true);
//            session.setAttribute("user", samlResponse.getUserID());

            OktaAuthPeer authPeer = new OktaAuthPeer("/saml-config.xml", "user", "logout");
            Principal principal = authPeer.getUserPrincipal(samlResponse);
            authPeer.putPrincipalInSessionContext(request, principal);

            response.sendRedirect("/");
            return false;

        } catch (SecurityPolicyException e) {
            System.out.println("SAML authentication unsuccessful");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

        return true;
    }
}
