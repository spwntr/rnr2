package com.thoughtworks.rnr.samlSpike;

import com.thoughtworks.rnr.samlSpike.util.Clock;
import com.thoughtworks.rnr.samlSpike.util.Identifier;
import com.thoughtworks.rnr.samlSpike.util.SimpleClock;
import com.thoughtworks.rnr.samlSpike.util.UUIDIdentifer;
import org.opensaml.common.SAMLObject;
import org.opensaml.common.SAMLVersion;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.core.*;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.util.XMLHelper;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import java.io.StringWriter;

/**
 * Wrapper for an outgoing SAMLRequest
 */
public class SAMLRequest {

    private final AuthnRequest request;

    public SAMLRequest(Application application) {
        this(application, new UUIDIdentifer(), new SimpleClock());
    }

    private SAMLRequest(Application application, Identifier identifier, Clock clock) {
        request = build(AuthnRequest.DEFAULT_ELEMENT_NAME);
        request.setID(identifier.getId());
        request.setVersion(SAMLVersion.VERSION_20);
        request.setIssueInstant(clock.dateTimeNow());
        request.setProtocolBinding(SAMLConstants.SAML2_POST_BINDING_URI);
        request.setAssertionConsumerServiceURL(application.getAuthenticationURL());

        Issuer issuer = build(Issuer.DEFAULT_ELEMENT_NAME);
        issuer.setValue(application.getIssuer());
        request.setIssuer(issuer);

        NameIDPolicy nameIDPolicy = build(NameIDPolicy.DEFAULT_ELEMENT_NAME);
        nameIDPolicy.setFormat(NameIDType.UNSPECIFIED);
        request.setNameIDPolicy(nameIDPolicy);

        RequestedAuthnContext requestedAuthnContext = build(RequestedAuthnContext.DEFAULT_ELEMENT_NAME);
        requestedAuthnContext.setComparison(AuthnContextComparisonTypeEnumeration.EXACT);
        request.setRequestedAuthnContext(requestedAuthnContext);

        AuthnContextClassRef authnContextClassRef = build(AuthnContextClassRef.DEFAULT_ELEMENT_NAME);
        authnContextClassRef.setAuthnContextClassRef(AuthnContext.PPT_AUTHN_CTX);
        requestedAuthnContext.getAuthnContextClassRefs().add(authnContextClassRef);
    }

    @SuppressWarnings("unchecked")
    private <T extends SAMLObject> T build(QName qName) {
        return (T) org.opensaml.Configuration.getBuilderFactory().getBuilder(qName).buildObject(qName);
    }

    public String toString() {
        try {
            Marshaller marshaller = org.opensaml.Configuration.getMarshallerFactory().getMarshaller(request);
            Element dom = marshaller.marshall(request);
            StringWriter stringWriter = new StringWriter();
            XMLHelper.writeNode(dom, stringWriter);
            return stringWriter.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public AuthnRequest getAuthnRequest() {
        return request;
    }
}
